# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['animelist', 'animelist.mycommands']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['animelist = animelist.main:app']}

setup_kwargs = {
    'name': 'animelist',
    'version': '0.1.0',
    'description': '',
    'long_description': '# MyAnimeList\n\n[italiano](README.it.md)\n\nMyAnimeList is a simple Command-line application that helps you keep track of the anime, films and manga you have\nwatched, are watching, or plan to watch. It allows you to manage your anime list from the comfort of the command line.\n\n## Features\n\n- List all anime\n- Filter the list by genre, status, and rating\n- Show information about a specific anime\n- Add new anime to your list\n- Remove anime from your list\n- Update information about existing anime\n- ...\n\n## Usage\n\n- **List:** To list all anime in your list\n    - Options:\n        - **--genre [genre]:** To filter your list by genre\n        - **--status [status]:** To filter your list by status\n        - **--rating [format]:** To filter your list by rating\n            - **format:** [min]:[max] (1:10, [min]: -> >=min, :[max] -> <=max)\n        - **--number [number]:** To limit the number of anime in the list\n    - **Example:**\n        - ./myanimelist list --genre action --status watching --rating "1:9"\n\n- **Show [name]:** To show information about a specific anime in your list\n    - **Example:**\n        - ./myanimelist show Attack on Titan\n\n- **Add [name]:** To add a new anime to your list\n    - Options (all parameters are optional):\n        - **--genre:** Treat the provided arguments as genre\n    - **Example:**\n        - ./myanimelist add Attack On Titan\n        - ./myanimelist add --genre action\n\n- **Remove [name]:** To remove an anime from your list\n    - Options (all parameters are optional):\n        - **--genre:** Treat the provided arguments as genre\n    - **Example:**\n        - ./myanimelist remove Attack on Titan\n        - ./myanimelist remove --genre action\n\n- **Update [name]:** To update an anime of your list\n    - Options (all parameters are optional, but at least one parameter needs to be provided):\n        - **--type [type]:** a new type\n            - **type:** Anime (default), Manga, Film\n        - **--name [name]:** a new name\n        - **--genre [genre]:** a new genre\n        - **--season [season]:** a new season\n        - **--episode [episode]:** a new episode\n        - **--status [status]:** a new status\n        - **--rating [rating]:** a new rating\n    - **Example:**\n        - ./myanimelist update --type film\n\n- **Watch [name] [number of episode (default=1)]:** To watch anime (increase the number of anime episodes)\n    - **Example:**\n        - ./myanimelist watch Attack On Titan 2\n\n## Installation\n\nTODO\n\n## License\n\nMyAnimeList is released under the MIT License.',
    'author': 'YangLorenzo',
    'author_email': 'yangrongwei2002@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
